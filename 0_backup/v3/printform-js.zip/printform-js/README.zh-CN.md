# PrintForm.js

[English](./README.md) | [简体中文](./README.zh-CN.md)

**PrintForm.js** 是一个轻量级（零依赖 Vanilla JS）的浏览器端分页排版脚本。

它的核心作用是：**把一个长 HTML 容器（`.printform`）自动拆分成多个符合打印纸张大小的页面**。它会自动处理页眉、页脚、表头重复、页码更新以及空白行填充（Dummy Rows）。

## 核心逻辑图解 (Logic Diagram)

为了帮助理解 `printform.js` 是如何工作的，请参考下方的流程图：

```mermaid
flowchart TD
    subgraph Raw_Input [原始 HTML 输入]
        RawContainer[".printform 容器"]
        Header[".pheader (页眉)"]
        DocInfo[".pdocinfo (文档信息)"]
        RowHeader[".prowheader (表头)"]
        RowItems[".prowitem (数据行 1..N)"]
        Footer[".pfooter (页脚)"]
    end

    subgraph Processing [PrintForm.js 处理逻辑]
        Start(开始格式化) --> InitPage[创建新页面 Page 1]
        InitPage --> AddHeader[插入 Header & DocInfo & RowHeader]
        AddHeader --> LoopRows{还有剩余数据行?}
        
        LoopRows -- 是 --> CheckSpace{当前页还能塞下吗?}
        
        CheckSpace -- 能 --> AppendRow[插入数据行 .prowitem]
        AppendRow --> UpdateHeight[更新当前页高度]
        UpdateHeight --> LoopRows
        
        CheckSpace -- 不能 --> FillDummy[填充空白行 (Dummy Rows)]
        FillDummy --> AddFooter[插入页脚 .pfooter]
        AddFooter --> NewPage[创建新页面 Page N+1]
        NewPage --> AddHeaderRepeat[插入重复的 Header & RowHeader]
        AddHeaderRepeat --> LoopRows
        
        LoopRows -- 否 (没数据了) --> FillDummyFinal[填充剩余空白行]
        FillDummyFinal --> AddFooterFinal[插入最终页脚]
        AddFooterFinal --> Finish(完成)
    end

    subgraph Output_Result [最终打印效果]
        Page1[第一页 (A4)]
        PageBreak[分页符]
        Page2[第二页 (A4)]
        PageN[...]
    end

    RawContainer --> Start
    Finish --> Output_Result
```

---

## 快速开始 (Quick Start)

### 1. 启动项目
你需要一个静态服务器来预览效果（避免浏览器跨域限制）。

```bash
# 方式 A: 使用 Python (推荐)
python3 -m http.server 8000

# 方式 B: 使用 Node/Vite
npm install
npm run dev
```

### 2. 预览
打开浏览器访问：
- `http://localhost:8000/index.html` (完整功能演示)
- `http://localhost:8000/example.html` (基础结构演示)

---

## 如何使用 (How to Use)

使用 PrintForm 不需要复杂的构建工具，只需要遵循特定的 **HTML 结构约定**。

### 1. 基础结构
在页面中创建一个 `class="printform"` 的 `div`，并配置纸张大小。

```html
<!-- 容器：定义纸张大小 (例如 A4 宽 750px 高 1050px) -->
<div class="printform" 
     data-papersize-width="750" 
     data-papersize-height="1050">

    <!-- 1. 页眉 (每页顶部重复) -->
    <div class="pheader">...</div>

    <!-- 2. 文档信息 (通常只在第一页显示，可通过配置重复) -->
    <div class="pdocinfo">...</div>

    <!-- 3. 表头 (表格列名，跨页时重复显示) -->
    <div class="prowheader">...</div>

    <!-- 4. 数据行 (核心内容，会自动拆分) -->
    <div class="prowitem">行 1</div>
    <div class="prowitem">行 2</div>
    <div class="prowitem">行 3...</div>

    <!-- 5. 页脚 (每页底部重复) -->
    <div class="pfooter">...</div>
    
</div>

<!-- 引入脚本 -->
<script src="./dist/printform.js"></script>
```

### 2. 关键 Class 说明

| Class | 说明 | 默认行为 |
| :--- | :--- | :--- |
| `.printform` | **根容器** | 脚本只处理这个容器内的内容。 |
| `.pheader` | **页眉** | 默认**每页重复**。 |
| `.pdocinfo` | **文档信息** | 通常用于发票抬头信息，默认**每页重复** (可关)。 |
| `.prowheader` | **表头** | 表格的列标题，默认**每页重复**。 |
| `.prowitem` | **数据行** | 这是**最小拆分单位**。脚本不会拆分一个 `.prowitem` 内部的内容，而是按行进行分页判断。 |
| `.pfooter` | **页脚** | 默认**只在最后一页** (可通过配置改为每页重复)。 |
| `.ptac` | **条款/长文本** | 用于不需要对齐的法律条款或长文本，会自动按段落拆分。 |

---

## 配置参数 (Configuration)

你可以直接在 `.printform` 元素上使用 `data-*` 属性来控制行为。

### 常用配置

| 属性 (Data Attribute) | 值示例 | 说明 |
| :--- | :--- | :--- |
| `data-papersize-width` | `750` | 纸张宽度 (px)。 |
| `data-papersize-height` | `1050` | 纸张高度 (px)。 |
| `data-orientation` | `portrait` / `landscape` | 纸张方向：纵向 / 横向。 |
| `data-repeat-header` | `y` / `n` | 是否每页重复页眉 (默认 `y`)。 |
| `data-repeat-footer` | `y` / `n` | 是否每页重复页脚 (默认 `n`)。 |
| `data-show-logical-page-number`| `y` / `n` | 是否显示页码 (如 "Page 1 of 3")。 |
| `data-n-up` | `1` / `2` | **N-Up 打印**：一张纸打印几页逻辑页 (例如设为 2 可实现双联单)。 |

### 示例
```html
<div class="printform"
     data-papersize-width="800"
     data-papersize-height="1100"
     data-repeat-footer="y"
     data-show-logical-page-number="y">
     ...
</div>
```

---

## 高级功能

### 1. 空白行填充 (Dummy Rows)
如果一页的内容没填满，PrintForm 会自动插入空白行来撑开高度，使页脚始终位于页面底部。
- 你可以自定义空白行的样式：
```html
<template class="custom-dummy-row-item-content">
  <tr style="height:20px;"><td style="border:0;">...</td></tr>
</template>
```

### 2. JS API 调用
脚本加载后会自动执行。如果你是动态生成的内容（如 AJAX 加载后），需要手动触发格式化：

```javascript
// 格式化页面上所有 .printform
PrintForm.formatAll();

// 或者只格式化特定节点
const myForm = document.querySelector('#invoice-1');
PrintForm.format(myForm);
```

### 3. 构建生产版本
如果你修改了源码 (`js/` 目录)，需要重新打包：

```bash
npm run build
```
产物位于 `dist/printform.js`。

---

## 常见问题 (FAQ)

**Q: 为什么页面内容被截断了？**
A: 检查 `.prowitem` 的高度是否超过了 `data-papersize-height` 减去页眉页脚后的可用空间。如果单行内容太高，它无法被放入任何一页。

**Q: 如何隐藏第一页的页眉？**
A: 目前逻辑倾向于保持一致性。如果需要特殊处理，建议使用 CSS 配合 `.printform_page_1` 类名进行控制，或者在数据准备阶段拆分 DOM。

**Q: 打印时边距不对？**
A: 打印机的物理边距受浏览器和打印驱动控制。建议在打印对话框中勾选 "背景图形" (Background graphics) 并将边距设为 "无" 或 "最小"。

---

## 目录结构

- `js/printform.js` - 入口文件
- `js/printform/formatter.js` - **核心逻辑** (分页计算都在这里)
- `js/printform/config.js` - 配置项定义
- `js/printform/dom.js` - DOM 操作辅助函数
- `index.html` - 完整测试用例