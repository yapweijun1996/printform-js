import PrintForm from "./printform.js";

export default PrintForm;
